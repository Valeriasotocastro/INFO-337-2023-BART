import pytest
import numpy as np
import tarea

@pytest.fixture
def mock_data():    
    return np.array([0, 0, 1, 1, 1])

@pytest.mark.parametrize(
    "alpha, expected",
    [
        (0.5, 0.625), 
        (1.0, 0.6),
        (2.0, 0.571429),
    ],
)
def test_part1(mock_data, alpha, expected):
    ans = tarea.coin_map(alpha, alpha, mock_data)
    return np.testing.assert_allclose(ans, expected, rtol=1e-5)

@pytest.mark.parametrize(
    "p, alpha, expected",
    [
        (0.25, 0.5, 0.551329), 
        (0.25, 1.0, 0.527344),
        (0.75, 0.5, 1.653987),
        (0.75, 1.0, 1.582031),
    ],
)
def test_part2(mock_data, p, alpha, expected):
    ans = tarea.coin_posterior(p, alpha, alpha, mock_data)
    return np.testing.assert_allclose(ans, expected, rtol=1e-5)

