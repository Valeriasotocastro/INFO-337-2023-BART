import numpy as np
from scipy.stats import beta as beta_distribution

# Estimador MAP de p
def coin_map(alpha: float, beta: float, x: np.ndarray) -> float:
    p = (alpha + np.sum(x)) / (alpha + beta + len(x))
    return p

# Posterior de p utilizando la distribución beta
def coin_posterior(p: float, alpha: float, beta: float, x: np.ndarray) -> float:
    alpha_N = alpha + np.sum(x)
    beta_N = beta + len(x) - np.sum(x)
    posterior = beta_distribution.pdf(p, alpha_N, beta_N)
    return posterior
