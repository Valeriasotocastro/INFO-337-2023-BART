[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/jnYQ8U1V)
# Actividad práctica: GMM

El objetivo de esta actividad es familiarizarse con GMM utilizando scikit-learn. Hay tres experimentos cubriendo dos usos de GMM: estimación de densidad y clustering. El primero usa datos sintéticos, el segundo usa datos reales (imágenes), y el último usa su propio ejemplo.

## Instrucciones generales

- Lea cuidadosamente `tarea.ipynb` y complete donde corresponda
- Los resultados se evaluarán en base al último *commit* antes de la fecha y hora de entrega
- Haga *commits* con sus avances regularmente. Se evaluará su progreso en base al histórico de *commits*. 
- Se espera que sigan el [código de ética de la ACM](https://www.acm.org/code-of-ethics)

