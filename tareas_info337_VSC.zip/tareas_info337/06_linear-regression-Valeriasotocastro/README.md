[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/Bky2g8Fn)
# Regresión Lineal


## Objetivo

El objetivo de esta actividad práctica es realizar un análisis de **regresión lineal**. Hay dos partes en esta tarea:

- Aborda un caso en el que se violan los supuestos de residuos 
- Desarrolla tus propias preguntas de investigación y respóndelas con el análisis de regresión lineal
 
 Tu tarea se calificará de acuerdo con el **rigor** de su proceso, teniendo en cuenta lo **minucioso y preciso** que es. Siga el pipeline (la canalización) en la clase/libro (con variación si es necesario).

Utilizaremos un dataset de consumo de gasolina en automóviles de distintas marcas y modelos del repositorio [UCI](https://archive.ics.uci.edu/ml/). 

## Instrucciones generales

- Asegúrese de tener [la última versión de nuestro libro de Jupyter](https://magister-informatica-uach.github.io/INFO337_2023/lectures/5_linear_regression/part2.html#un-pipeline-basico-de-modelamiento-con-regresion-python) (usando el último 'commit') para obtener la última versión del pipeline (canalización).
- Puede usar Python (`statsmodels`) o R. 
- Lea cuidadosamente el cuadernillo `enunciado.ipynb` y complete donde corresponda
- Realice commits con sus avances regularmente
- Se espera que sigan el [código de ética de la ACM](https://www.acm.org/code-of-ethics)


