import numpy as np
import scipy.stats

def is_normal(data: np.ndarray, alpha: float = 0.05) -> bool:
    """
    La función retorna verdadero si los datos provienen de una distribución normal
    """
    _, p_value = scipy.stats.kstest(data, 'norm')
    return p_value > alpha

def compare_samples1(sample1: np.ndarray, sample2: np.ndarray, alpha: float = 0.05) -> bool:
    """
    La función retorna verdadero si las muestras provienen de la misma distribución
    """
    _, p_value = scipy.stats.ks_2samp(sample1, sample2)
    return p_value > alpha

def compare_samples2(sample1: np.ndarray, sample2: np.ndarray, alpha: float = 0.05) -> bool:
    """
    La función retorna verdadero si las muestras provienen de la misma distribución
    """
    _, p_value = scipy.stats.ranksums(sample1, sample2)
    return p_value > alpha
