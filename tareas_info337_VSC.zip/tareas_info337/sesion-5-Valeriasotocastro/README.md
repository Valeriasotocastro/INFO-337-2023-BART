[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/kSBZ3I6i)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=12240570&assignment_repo_type=AssignmentRepo)
# Tests no paramétricos

## Objetivo

Familiarizarse con el uso de `scipy` para realizar tests estadísticos no paramétricos 

## Instrucciones generales

- Lean cuidadosamente `enunciado.ipynb` y completen donde corresponda
- Implemente las funciones y clases que se piden en `tarea.py`
- Los resultados se evaluarán en base al último commit antes de la fecha y hora de entrega
- Se espera que sigan el código de ética de la [ACM](https://www.acm.org/code-of-ethics)

