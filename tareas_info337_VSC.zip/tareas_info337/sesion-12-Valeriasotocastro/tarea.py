import numpy as np
import jax.numpy as jnp
import jax.random as random
import numpyro
import numpyro.distributions as dist

def model(x, y=None):
    theta = numpyro.sample("theta", dist.Normal(jnp.zeros(4), jnp.ones(4)).to_event(1))
    with numpyro.plate('data', size=x.shape[0]):
        intensity = numpyro.deterministic('lambda', jnp.exp(theta[0] + jnp.dot(x, theta[1:])))
        numpyro.sample("y", dist.Poisson(rate=intensity), obs=y)
