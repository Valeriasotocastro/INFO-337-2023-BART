[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/19V5TzQj)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=12695423&assignment_repo_type=AssignmentRepo)
This is a template environment, pre-configured to run Github Classroom assessments.
<a href="https://mybinder.org/v2/gh/elianascheihing/YOUR_FORK/main?urlpath=git-pull%3Frepo%3Dhttps%253A%252F%252Fgithub.com%252F${REPOSITORY_ACCOUNT}%252F${REPOSITORY_SLUG}%26targetPath%3DINFO337-assignments%26urlpath%3Drstudio%252F%26branch%3Dmain">
  <img src="https://mybinder.org/badge_logo.svg" alt="Launch Binder"/>
</a>


# Modelos lineales avanzados
## Instrucciones generales
- En su desarrollo considere el código de ética [ACM Code of Ethics](https://www.acm.org/code-of-ethics)
- Esta sesión considera un notebook en Python para el ajuste de una regresion polinomial y otro notebook en R para el ajuste de regresiones a respuesta discreta.
- Como de costumbre, escriba sus respuestas y discusión de resultados en cada uno de los notebooks.
- Guarde sus gráficos y/o respuestas escritas a mano en la carpeta `images` y las puede incorporar en el cuadernillo utilizando la instrucción:
<center><img src="images/probPuntual.png" width=200></center>
    

