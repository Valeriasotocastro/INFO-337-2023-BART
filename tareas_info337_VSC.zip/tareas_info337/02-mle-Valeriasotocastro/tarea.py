import numpy as np
import math 
def bernoulli_log_likelihood(p: float, x: np.ndarray) -> float:
    i = 1
    L = 0
    for i in range (len(x)):
        L = L + x[i]*math.log(p)+(1-x[i])*math.log(1-p)
    return L

def bernoulli_mle(x: np.ndarray) -> float:
    p = bernoulli_log_likelihood
    i = 1
    L = 0
    for i in range (len(x)):
        L = L + x[i]
    L = L / len(x)
    return L
    

def bernoulli_variance_mle(x: np.ndarray) -> float:
    p = bernoulli_mle(x)
    i = 0
    L = (p*(1-p)) / len(x)
    return L

