import pytest
import numpy as np
import tarea

@pytest.fixture
def mock_data():
    return np.array([0, 0, 1, 1, 1])

@pytest.mark.parametrize(
    "p, expected",
    [
        (0.25, -4.734247), 
        (0.5, -3.465736),
        (0.75, -3.635635),
    ],
)
def test_part1(mock_data, p, expected):
    ans = tarea.bernoulli_log_likelihood(p, mock_data)
    return np.testing.assert_allclose(ans, expected, rtol=1e-5)

def test_part2(mock_data):
    ans = tarea.bernoulli_mle(mock_data)
    expected = 0.6
    return np.testing.assert_allclose(ans, expected, rtol=1e-5)

def test_part3(mock_data):
    ans = tarea.bernoulli_variance_mle(mock_data)
    expected = 0.048
    return np.testing.assert_allclose(ans, expected, rtol=1e-5)
